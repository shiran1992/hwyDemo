/**
 * Created by shiran on 2017/6/18.
 */
const userInfoActions = require('./userInfo');

const Actions = [
	userInfoActions,
];

let actions = {};
Actions.forEach((item) => {
	let old_count = Object.keys(actions).length;
	let new_count = Object.keys(item).length;
	Object.assign(actions, item);
	if (Object.keys(actions).length !== old_count + new_count) {
		console.error('same action!');
	}
});

module.exports = actions;
