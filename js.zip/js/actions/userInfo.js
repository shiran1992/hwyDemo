/**
 * Created by shiran on 2017/6/18.
 */
import * as types from './actionTypes';

export function saveInfo (info) {
	return { type: types.USERINFO, info: info };
}