export const USERINFO = 'hwy.app.USERINFO';

