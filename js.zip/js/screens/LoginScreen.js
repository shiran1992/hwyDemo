/**
 * Created by shiran on 2017/7/3.
 */
import React, { Component } from 'react';
import {
	AppRegistry,
	StyleSheet,
	Text,
	View
} from 'react-native';
var RCTDeviceEventEmitter = require('RCTDeviceEventEmitter');
class LoginScreen extends Component {
	render() {
		return (
			<View style={styles.container}>
				<Text style={styles.welcome} onPress={()=>{
this.onPressLogin();
				}}>
					LoginScreen
				</Text>
			</View>
		);
	}

	onPressLogin(){
		// this.props.navigator.push({
		// 	title: '悠游世界',
		// 	screen: 'hwy.MiniGameScreen'
		// })
		RCTDeviceEventEmitter.emit('hwy_isLogin', '1' );
	}
}

const styles = StyleSheet.create({
	container: {
		flex: 1,
		justifyContent: 'center',
		alignItems: 'center',
		backgroundColor: '#F5FCFF',
	},
	welcome: {
		fontSize: 20,
		textAlign: 'center',
		margin: 10,
	},
	instructions: {
		textAlign: 'center',
		color: '#333333',
		marginBottom: 5,
	},
});

export default LoginScreen;