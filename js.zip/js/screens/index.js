/**
 * Created by shiran on 2017/6/12.
 */
import { Navigation } from 'react-native-navigation';

import IndexTabScreen from './IndexTabScreen';
import MessageTabScreen from './MessageTabScreen';
import FriendTabScreen from './FriendTabScreen';
import ExploreTabScreen from './ExploreTabScreen';
import LeftSideMenu from './LeftSideMenu';
import RightSideMenu from './RightSideMenu';
import LoginScreen from './LoginScreen';
import MiniGameScreen from './explore/MiniGameScreen';

// register all screens of the app (including internal ones)
export function registerScreens(store, Provider) {
	Navigation.registerComponent('hwy.IndexTabScreen', () => IndexTabScreen, store, Provider);
	Navigation.registerComponent('hwy.MessageTabScreen', () => MessageTabScreen, store, Provider);
	Navigation.registerComponent('hwy.FriendTabScreen', () => FriendTabScreen, store, Provider);
	Navigation.registerComponent('hwy.ExploreTabScreen', () => ExploreTabScreen, store, Provider);
	Navigation.registerComponent('hwy.LeftSideMenu', () => LeftSideMenu, store, Provider);
	Navigation.registerComponent('hwy.RightSideMenu', () => RightSideMenu, store, Provider);
	Navigation.registerComponent('hwy.LoginScreen', () => LoginScreen, store, Provider);
	Navigation.registerComponent('hwy.MiniGameScreen', () => MiniGameScreen, store, Provider);
}