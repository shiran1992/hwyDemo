/**
 * Created by shiran on 2017/6/12.
 */
import React, { Component } from 'react';
import {
	AppRegistry,
	StyleSheet,
	Text,
	View,
	TouchableHighlight
} from 'react-native';
import colors from './utils/colors';
import { saveInfo } from '../actions';
import * as types from '../actions/actionTypes';
class ExploreTabScreen extends Component {
	static navigatorStyle = {
		drawUnderNavBar: false,
		drawUnderTabBar: false,
		navBarTranslucent: false
	};
	render () {
		return (
			<View style={styles.container}>
				<Text style={styles.welcome} >ExploreTabScreen</Text>
				<Text style={styles.welcome} onPress={()=>{
					this.saveInfoToRedux();
				}}>保存信息</Text>
				<TouchableHighlight onPress={() => this.pushToMiniGame() } style={{borderRadius: 5}}>
					<View style={{ paddingVertical: 5, paddingHorizontal: 10, backgroundColor: colors.buttonBG, borderRadius: 5 }}>
						<Text style={{ color: 'white', fontSize: 16 }}>push进入下一级界面</Text>
					</View>
				</TouchableHighlight>
			</View>
		);
	}

	//保存数据到redux
	saveInfoToRedux() {
		// this.props.dispatch(saveInfo('石然'));
		this.props.dispatch({type:types.USERINFO, info:'石然'});
	}

	pushToMiniGame () {
		this.props.navigator.push({
			title: '悠游世界',
			screen: 'hwy.MiniGameScreen'
		});
	}

}

const styles = StyleSheet.create({
	container: {
		flex: 1,
		justifyContent: 'center',
		alignItems: 'center',
		backgroundColor: '#F5FCFF',
	},
	welcome: {
		fontSize: 20,
		textAlign: 'center',
		margin: 10,
	},
	instructions: {
		textAlign: 'center',
		color: '#333333',
		marginBottom: 5,
	},
});

export default ExploreTabScreen;