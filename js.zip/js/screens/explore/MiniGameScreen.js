/**
 * Created by shiran on 2017/6/12.
 */
import React, { Component } from 'react';
import {
	AppRegistry,
	StyleSheet,
	Text,
	View
} from 'react-native';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import * as InfoActions from '../../actions/userInfo';
import MiniGameView from './MiniGameView';
class MiniGameScreen extends Component {
	static navigatorStyle = {
		drawUnderNavBar: false,
		drawUnderTabBar: true,
		tabBarHidden: true
	};

	render () {
		return (
			<View style={styles.container}>
				<Text style={styles.welcome}>
					MiniGameScreen
				</Text>
				<Text style={styles.welcome}>
					姓名:{this.props.info}
				</Text>
				<Text style={styles.welcome} onPress={()=> {
					this.saveInfo()
				}}>
					保存
				</Text>
				<MiniGameView/>
			</View>
		);
	}

	saveInfo () {
		this.props.actions.saveInfo('东方国际德国');
	}

}

const styles = StyleSheet.create({
	container: {
		flex: 1,
		justifyContent: 'center',
		alignItems: 'center',
		backgroundColor: '#F5FCFF',
	},
	welcome: {
		fontSize: 20,
		textAlign: 'center',
		margin: 10,
	},
	instructions: {
		textAlign: 'center',
		color: '#333333',
		marginBottom: 5,
	},
});

function mapStateToProps (state, ownProps) {
	return {
		info: state.userInfo.info,
	};
}

function mapDispatchToProps (dispatch) {
	return {
		actions: bindActionCreators(InfoActions, dispatch)
	};
}

export default connect(mapStateToProps, mapDispatchToProps)(MiniGameScreen);