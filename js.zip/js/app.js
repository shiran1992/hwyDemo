/**
 * Created by shiran on 2017/6/12.
 */
import React, { Component } from 'react';
import {
	AppRegistry,
	StyleSheet,
	Platform,
	Image,
	Text,
	View
} from 'react-native';
var RCTDeviceEventEmitter = require('RCTDeviceEventEmitter');
import { Navigation } from 'react-native-navigation';
import { registerScreens } from './screens';
import configureStore from './store/configureStore';
var { Provider } = require('react-redux');

const store = configureStore();

const LoginAppConfig = {
	screen: {
		screen: 'hwy.LoginScreen',
		title: '登录',
		navigatorStyle: {}
	}
};

const TabAppConfig = {
	animationType: 'none',
	title: '好玩友',

	drawer: {
		left: {
			screen: 'hwy.LeftSideMenu'
		},
		type: 'MMDrawer',
		animationType: 'slide',
		disableOpenGesture: false,
	},

	tabsStyle: {
		tabBarSelectedButtonColor: '#4cc0fc',
		tabBarButtonColor: '#929292'
	},

	tabs: [
		{
			label: '首页',
			screen: 'hwy.IndexTabScreen',
			icon: require('../img/tab/index.png'),
			selectedIcon: require('../img/tab/index_sel.png'),
			title: '',
			navigatorStyle: {},
		},
		{
			label: '消息',
			screen: 'hwy.MessageTabScreen',
			icon: require('../img/tab/message.png'),
			selectedIcon: require('../img/tab/message_sel.png'),
			title: '消息',
			doubleClick: true,
			navigatorStyle: {},
		},
		{
			label: '玩友',
			screen: 'hwy.FriendTabScreen',
			icon: require('../img/tab/contact.png'),
			selectedIcon: require('../img/tab/contact_sel.png'),
			title: '玩友',
			navigatorStyle: {},
		},
		{
			label: '探索',
			screen: 'hwy.ExploreTabScreen',
			icon: require('../img/tab/explore.png'),
			selectedIcon: require('../img/tab/explore_sel.png'),
			title: '探索',
			navigatorStyle: {},
		},
	],
};

class App {
	constructor () {
		registerScreens(store, Provider);
		Navigation.startSingleScreenApp(LoginAppConfig);

		RCTDeviceEventEmitter.addListener('hwy_isLogin', (args) => {
			if (args === '0') {
				Navigation.startSingleScreenApp(LoginAppConfig);
			} else if (args === '1') {
				Navigation.startTabBasedApp(TabAppConfig);
			}
		});
	}
}

module.exports = App;