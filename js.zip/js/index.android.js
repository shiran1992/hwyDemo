/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import App from './js/app';

const app = new App();