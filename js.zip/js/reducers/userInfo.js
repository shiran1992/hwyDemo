/**
 * Created by shiran on 2017/6/18.
 */
import * as types from '../actions/actionTypes';
import initialState from './initialState';
export default function userInfo(state = initialState, action = {}) {
	switch (action.type) {
		case types.USERINFO:
			return { ...state, info: action.info };
		default:
			return state;
	}
}
