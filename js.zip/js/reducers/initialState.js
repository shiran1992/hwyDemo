export default {
	userInfo: {
		info: '123'
	}
};
