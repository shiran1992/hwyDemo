/**
 * Created by shiran on 2017/6/18.
 */
import userInfo from './userInfo';
import { combineReducers } from 'redux';

module.exports = combineReducers({
	userInfo
});
